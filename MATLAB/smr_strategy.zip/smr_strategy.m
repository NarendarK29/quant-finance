function varargout = smr_strategy(varargin)
%smr_strategy View a stock's buy/sell recommendations based on a synthesis
%of three indicators: SMA, MACD, and RSI
%
%Syntax: 
%   smr_strategy 
%Inputs:
%    none
%Outputs:
%    none
%An internet connection is required.
%
%This tool performs technical analysis of stock data automatically and
%suggests times at which an investor should buy or sell a particular stock.
%
%The plot of stock price vs. time contains red and green dots. Red dots
%correspond to days that the strategy suggests to sell, and green dots
%correspond to days that the strategy suggests to buy. 
%
%Definitions:
%   -MACD: Moving Average Convergence/Divergence. The difference between a 
%   long period and short period Exponential Moving Average of the stock 
%   price
%   -MACD Signal: The EMA of the MACD described above
%   -SMA: Simple Moving Average. The average stock price over the last n
%   days
%   -RSI: Relative strength index. Fluctuates between 0 and 100. Over 70 is
%   considered "overbought" (and expected to fall) while under 30 indicates
%   "oversold" (and expected to rise)
%
%Recommendations are based on simple moving average, relative strength index,
%and moving avg convergence/divergence. This algorithm to
%this strategy is from the book "The Neatest Little Guide to Stock
%Market Investing" by Jason Kelly and is outlined below. 
%
%Stock data is from Yahoo's! free, undocumented, non-commercial API. 
%
% At least two (2) of these three (3) conditions must be met in order to 
%recommend a buy or sell: 
% 1. MACD and MACD signal have recently intersected. If MACD signal is 
%rising on intersection buy, otherwise sell
% 2. rsi < 30 and increasing (buy) or > 70 and decreasing (sell) 
% 3. current price crosses sma (cross upwards = buy, downwards = sell) 
%
% There are no guarantees made as to the effectiveness of the tool, so
% invest at your own risk. The author is not responsible for any losses you
% may incur when following this strategy.
%
% sma_strategy Version 0.5, � Chad Smith



% Last Modified by GUIDE v2.5 05-Jan-2014 00:06:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @smr_strategy_OpeningFcn, ...
                   'gui_OutputFcn',  @smr_strategy_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before smr_strategy is made visible.
function smr_strategy_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to smr_strategy (see VARARGIN)

set(hObject,'name','SMR Strategy');

% Choose default command line output for smr_strategy
handles.output = hObject;
set(hObject,'toolbar','none');

% set cursor update function
cursorMode = datacursormode(gcf);
set(cursorMode,'UpdateFcn',{@UpdateCursor gcf handles});

% Update handles structure
handles.versionNumber = '0.5';
guidata(hObject, handles);



% --- Outputs from this function are returned to the command line.
function varargout = smr_strategy_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_ticker_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ticker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ticker as text
%        str2double(get(hObject,'String')) returns contents of edit_ticker as a double




% --- Executes during object creation, after setting all properties.
function edit_ticker_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_stockDataWindow_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function edit_stockDataWindow_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_smaPeriod_Callback(hObject, eventdata, handles)
% hObject    handle to edit_smaPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_smaPeriod as text
%        str2double(get(hObject,'String')) returns contents of edit_smaPeriod as a double


% --- Executes during object creation, after setting all properties.
function edit_smaPeriod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_smaPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_rsiPeriod_Callback(hObject, eventdata, handles)
% hObject    handle to edit_rsiPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_rsiPeriod as text
%        str2double(get(hObject,'String')) returns contents of edit_rsiPeriod as a double


% --- Executes during object creation, after setting all properties.
function edit_rsiPeriod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_rsiPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_dayBuffer_Callback(hObject, eventdata, handles)
% hObject    handle to edit_dayBuffer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_dayBuffer as text
%        str2double(get(hObject,'String')) returns contents of edit_dayBuffer as a double


% --- Executes during object creation, after setting all properties.
function edit_dayBuffer_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_dayBuffer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_submitQuery.
function handles = pushbutton_submitQuery_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_submitQuery (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%clear plotting pane
curPlotPaneHandles = get(handles.uipanel_plots,'Children');
delete(curPlotPaneHandles)



%% Get required info
ticker = get(handles.edit_ticker,'string');
stockDataWindow=str2num(get(handles.edit_stockDataWindow,'string'));
dayBuffer=str2num(get(handles.edit_dayBuffer,'string'));
smaPeriod=str2num(get(handles.edit_smaPeriod,'string'));
rsiPeriod=str2num(get(handles.edit_rsiPeriod,'string'));
macdP(1)=str2num(get(handles.edit_macdP1,'string'));
macdP(2)=str2num(get(handles.edit_macdP2,'string'));
macdP(3)=str2num(get(handles.edit_macdP3,'string'));

requiredHistoryInDays = max([smaPeriod, rsiPeriod, max(macdP) ] );
requestedHistoryInDays = stockDataWindow*30;

if requiredHistoryInDays >= requestedHistoryInDays
   errordlg(['Indicator period must be less than stock data window. ' ...
       'Increase stock data window or decrease indicator period, ' ...
   'then try again.'])
   return
end

uicontrol('Parent', handles.uipanel_plots, ...
    'Style', 'text',...
    'String','Please Wait', ...
    'Units','Normalized', ...
    'Position',[0, 0.5, 1, 0.2], ...
    'FontSize',20, ...
    'tag','pleaseWait');

drawnow
pause(0.1)

% retrieve data from Yahoo! and attach results to handles
[success, msg, handles] = metrics_backend(ticker, stockDataWindow, dayBuffer, smaPeriod, rsiPeriod, handles, macdP);

delete(findobj('tag','pleaseWait'))

if ~success
    errordlg(msg)
    
    uicontrol('Parent', handles.uipanel_plots, ...
    'Style', 'text',...
    'String','Error connecting. Please try again.', ...
    'Units','Normalized', ...
    'Position',[0,.5,1,.2], ...
    'FontSize',20, ...
    'tag','pleaseWait');

    error(msg)
    return
end

% plot data
handles = plot_smr_data(handles);

% Update handles structure
guidata(hObject, handles);






% --- Executes on button press in pushbutton_bufferQuest.
function pushbutton_bufferQuest_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_bufferQuest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
helpText  = sprintf(['The number of days around a dot in the lower three plots to look for dots in the other two plots.\n\n' ...
    'For example if SMA has a buy indicator (green dot) on June 1st but not on June 2nd, and a day later MACD has one on June 2nd but not June 1st, a buffer of 0 won''t trigger an overall buy signal but a buffer of 1 will.\n\n' ...
    'The higher this number the more indicators. Too low will have too few indicators, too high will have too many.']);
msgbox(helpText);


% --- Executes on button press in pushbutton_questRsi.
function pushbutton_questRsi_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_questRsi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
url='http://stockcharts.com/school/doku.php?id=chart_school:technical_indicators:relative_strength_index_rsi';
dosCmd = ['start ' url ];
dos(dosCmd);

% --- Executes on button press in pushbutton_questSma.
function pushbutton_questSma_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_questSma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
url='www.investopedia.com/terms/s/sma.asp';
dosCmd = ['start ' url ];
dos(dosCmd);

% --- Executes on button press in pushbutton_questMonths.
function pushbutton_questMonths_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_questMonths (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox(sprintf(['Months of data to plot prior to current date.']));



function edit_macdP1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_macdP1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_macdP1 as text
%        str2double(get(hObject,'String')) returns contents of edit_macdP1 as a double


% --- Executes during object creation, after setting all properties.
function edit_macdP1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_macdP1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
url='http://www.investopedia.com/terms/m/macd.asp';
dosCmd = ['start ' url ];
dos(dosCmd);

function edit_macdP2_Callback(hObject, eventdata, handles)
% hObject    handle to edit_macdP2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_macdP2 as text
%        str2double(get(hObject,'String')) returns contents of edit_macdP2 as a double


% --- Executes during object creation, after setting all properties.
function edit_macdP2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_macdP2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit_macdP3_Callback(hObject, eventdata, handles)
% hObject    handle to edit_macdP3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_macdP3 as text
%        str2double(get(hObject,'String')) returns contents of edit_macdP3 as a double


% --- Executes during object creation, after setting all properties.
function edit_macdP3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_macdP3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





% --- Executes on button press in pushbutton_resetDates.
function pushbutton_resetDates_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_resetDates (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axesHandles=get(handles.uipanel_plots,'children');
for i=1:length(axesHandles)
    %loop all subplots
    axes(axesHandles(i))
    xlim(handles.UserData.xlimits{i});
end




% --------------------------------------------------------------------
function file_Callback(hObject, eventdata, handles)
% hObject    handle to file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(gcf)


% --------------------------------------------------------------------
function Untitled_5_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_4_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

helpText = sprintf(['SMR Strategy v' handles.versionNumber '\n\n' ...
    'Programmed by Chad Smith\n\n' ...
    'Inspired by Jason Kelly''s book "The Neatest Little Guide to Stock Market Investing"']);

helpdlg(helpText,'About')



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit_rsiPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_rsiPeriod as text
%        str2double(get(hObject,'String')) returns contents of edit_rsiPeriod as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_rsiPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_questRsi.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_questRsi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton_addCursor.
function pushbutton_addCursor_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_addCursor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%% Find price subplot
%use index 1 (which is not always the top one) by default if price isnt
%plotted
topSubplot=1;
axesHandles=get(handles.uipanel_plots,'children');
for i = 1:length(axesHandles)
    curTitleH = get(axesHandles(i),'title');
    curTitle = get(curTitleH,'string');
    if regexpi(curTitle,'price')
        topSubplot = i;
    end
end
axes(axesHandles(topSubplot));

%% Find lines
linesOfPlot = get(gca,'children');
lineIndxs = [];
for i=1:length(linesOfPlot)
    curLineH = linesOfPlot(i);
    if any(strcmpi(fieldnames(get(curLineH)),'XData')) ;% only lines have XData field
        lineIndxs = [lineIndxs i];
    end
end

%% Grab x y data
for i=1:length(lineIndxs)
    curLineH = linesOfPlot(lineIndxs(i));
    xdata{i} = get(curLineH,'XData');
    ydata{i} = get(curLineH,'YData');
end

%% Set default target line and default xy position
datatipPos = [xdata{1}(ceil(end/2)),ydata{1}(ceil(end/2))];
hTarget=linesOfPlot(lineIndxs(1));

%% Try to find a more desireable line and/or position to insert datatip
% Grab plot limits
xlims = get(gca,'xlim');
xmin=xlims(1); xmax=xlims(2);
ylims = get(gca,'ylim');
ymin=ylims(1); ymax=ylims(2);

% Find lines that lie inside
for i=1:length(lineIndxs)
    curLineH = linesOfPlot(lineIndxs(i));
    dataPtsInRange = find((xdata{i}<=xmax & xdata{i}>=xmin & ydata{i}<=ymax & ydata{i}>=ymin));
    if ~isempty(dataPtsInRange)
        indx  = dataPtsInRange(ceil(end/2));
        datatipPos = [xdata{i}(indx), ydata{1}(indx)];
        hTarget=curLineH;
        break ;% use first line even if multiple lines are within box
    end
end


%% Create datatip
cursorMode = datacursormode(gcf);
set(cursorMode, 'enable','on');
hDatatip = cursorMode.createDatatip(hTarget);

%% Update the datatip marker appearance
% dataTipColor = get(handles.pushbutton_datatipColor,'background');
% dataTipColor=get(hTarget,'Color');
set(hDatatip, 'MarkerSize',8, 'MarkerFaceColor','y', ...
    'MarkerEdgeColor','k', 'Marker','o', 'HitTest','off', ...
    'FontSize',10,'FontName','Courier New','UpdateFcn',{@UpdateCursor gcf handles});

% Move the datatip to the desired position 
%(update is a built in matlab function)
% update(hDatatip, datatipPos);
update(hDatatip);




% --- Executes on button press in pushbutton_removeCursor.
function pushbutton_removeCursor_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_removeCursor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cursorMode = datacursormode(gcf);
try
    cursorMode.removeDataCursor(cursorMode.CurrentDataCursor)
end




function cursorText = UpdateCursor(obj,event_obj,cfig, handles)
% get data cursor handles
dataCursor = findall(cfig,'type','hggroup','Position',event_obj.Position);

cursorMode = datacursormode(gcbf);
dataTipsH=cursorMode.DataCursors;

% change font for data cursor
set(dataCursor,'FontSize',10,'FontName','Courier New');

for i =1:length(dataTipsH)
%     lineH = get(dataTipsH(i),'Host');
%     lineColor = get(lineH,'Color');
    set(dataTipsH(i),'MarkerFaceColor','y','MarkerSize',8,  ...
    'MarkerEdgeColor','k', 'Marker','o', 'HitTest','off', ...
    'FontSize',10,'FontName','Courier New');

    pos=get(dataTipsH(i),'Position');
    x=pos(1);
    y=pos(2);
    
    % update cursor text for this cursor
    cursorText=sprintf([datestr(x,'mmm dd')  '\n' ...
        '$' num2str(y) ]);
    set(dataTipsH(i),'String',cursorText);
end

% get x,y positions
x=event_obj.Position(1);
y=event_obj.Position(2);

% set cursor text
lineH = get(event_obj,'Target');
signalName = get(lineH,'UserData');
cursorText = sprintf([datestr(x,'mmm dd')  '\n' ...
    '$' num2str(y) ]);



function [success, msg, handles] = metrics_backend(ticker, stockDataWindow, dayBuffer, smaPeriod, rsiPeriod, handles, macdP)

if nargin == 0    
    ticker='spy';
    stockDataWindow = 12; % months of data to get from yahoo!
    dayBuffer = 3; % days
    smaPeriod = 50; % days
    rsiPeriod = 14; % days
    macdPeriod(1) = 26;
    macdPeriod(2) = 12;
    macdPeriod(3) = 9;
    handles=[];
end

%% GET RAW DATA
[success, msg, prices,dates,datesStr,volumes,stockName] = get_stock_data(ticker, stockDataWindow);

if ~success
   return
end

%% COMPUTE SMR_STRATEGY
macdResults = get_macd_results(prices, dates, datesStr, dayBuffer, macdP);
smaResults = get_sma_results(prices, dates, volumes, smaPeriod, datesStr, dayBuffer);
rsiResults = get_rsi_results(prices, dates, rsiPeriod, datesStr, dayBuffer);

%% FIND TIMES OF INTEREST
[buyDays, buyDates, pricesOnBuyDates, sellDays, sellDates, pricesOnSellDates] = find_times_of_interest(prices, macdResults, smaResults, rsiResults, dates, datesStr);

handles.UserData.ticker = ticker;
handles.UserData.stockName = stockName;
handles.UserData.dates = dates;
handles.UserData.prices = prices;
handles.UserData.volumes = volumes;
handles.UserData.macdRes = macdResults;
handles.UserData.smaRes = smaResults;
handles.UserData.rsiRes = rsiResults;
handles.UserData.buyDates = buyDates;
handles.UserData.sellDates = sellDates;
handles.UserData.pricesOnBuyDates = pricesOnBuyDates;
handles.UserData.pricesOnSellDates = pricesOnSellDates;

% Update handles structure
guidata(handles.uipanel_plots, handles);






function [buyDays, buyDates, pricesOnBuyDates, sellDays, sellDates, pricesOnSellDates] = find_times_of_interest(prices, macdResults,smaResults,rsiResults, stockDates, stockDatesStr)
macdSma.goingUp = find_time_overlap(macdResults.datesGoingUpWithBuffer, smaResults.datesGoingUpWithBuffer);
macdSma.goingDown = find_time_overlap(macdResults.datesGoingDownWithBuffer, smaResults.datesGoingDownWithBuffer);

macdRsi.goingUp = find_time_overlap(macdResults.datesGoingUpWithBuffer,rsiResults.datesGoingUpWithBuffer);
macdRsi.goingDown = find_time_overlap(macdResults.datesGoingDownWithBuffer,rsiResults.datesGoingDownWithBuffer);

smiRsi.goingUp = find_time_overlap(smaResults.datesGoingUpWithBuffer,rsiResults.datesGoingUpWithBuffer);
smiRsi.goingDown = find_time_overlap(smaResults.datesGoingDownWithBuffer,rsiResults.datesGoingDownWithBuffer);

% combine all buy days
buyDays = union(macdSma.goingUp, macdRsi.goingUp);
if ~isempty(buyDays)
    buyDays = cellstr(datestr(union(buyDays,  smiRsi.goingUp),23));
end

% combine all sell days
sellDays = union(macdSma.goingDown, macdRsi.goingDown);
if ~isempty(sellDays)
    sellDays = cellstr(datestr(union(sellDays, smiRsi.goingDown),23));
end

% remove any days added in by buffer that don't fall on trading days
buyDays = intersect(buyDays, stockDatesStr);
sellDays = intersect(sellDays, stockDatesStr);

%% this list should be non existent, but in case any conflicting
% buy/sell flags fall on the same day, remove them
removeMeBuyDays = intersect(buyDays, sellDays);
removeMeSellDays = intersect(sellDays,buyDays);
for i=1:length(removeMeBuyDays)
    buyDays = buyDays(~cregexp(buyDays, removeMeBuyDays{i}));
end
for i=1:length(removeMeSellDays)
    sellDays = sellDays(~cregexp(sellDays, removeMeSellDays{i}));
end

% sort days
buyDays = sort_datesStr(buyDays);
sellDays = sort_datesStr(sellDays);

% create date numbers for plotting
buyDates = [];
sellDates = [];
if ~isempty(buyDays)
    buyDates = datenum(buyDays);
end
if ~isempty(sellDays)
    sellDates= datenum(sellDays);
end

% calculate prices on buy/sell days
pricesOnBuyDates = prices(ismember(stockDates,buyDates));
pricesOnSellDates = prices(ismember(stockDates,sellDates));


function commonDates = find_time_overlap(cellArray1, cellArray2)
% inputs two cell arrays
% return a cell array of dates common to both
b = ismember(cellArray1,cellArray2);
commonDates = cellArray1(b);



function [results] = get_macd_results(prices,dates, datesStr, dayBuffer, macdPeriod)
[results.macdIndicator, results.macdDiff] = macd(prices, macdPeriod(1),macdPeriod(2),macdPeriod(3));
histogramData = results.macdIndicator - results.macdDiff;

results.goingUp = find(   diff(  sign(histogramData)   )   > 0 )   ;
results.datesGoingUp = datesStr(results.goingUp);
results.daysGoingUp = dates(results.goingUp);

results.datesGoingUpWithBuffer={};
results.datesGoingUpWithBuffer = create_buffer(results.daysGoingUp, dayBuffer);

results.goingDown = find(   diff(  sign(histogramData)   )  < 0 )   ;
results.datesGoingDown = datesStr(results.goingDown);
results.daysGoingDown = dates(results.goingDown);

results.datesGoingDownWithBuffer = create_buffer(results.daysGoingDown, dayBuffer);

results = calc_most_recent_buysell_event(results);



function [results] = get_sma_results(prices,dates,volumes, smaPeriod, datesStr, dayBuffer)
results.price = sma(prices,smaPeriod);
results.volume = sma(volumes,smaPeriod);
histData = prices - results.price; % current price - avg price = difference


results.goingUp = find(   diff(  sign(histData)   )   > 0 )   ;
results.datesGoingUp = datesStr(results.goingUp);
results.daysGoingUp = dates(results.goingUp);

results.datesGoingUpWithBuffer = create_buffer(results.daysGoingUp, dayBuffer);

results.goingDown = find(   diff(  sign(histData)   )  < 0 )   ;
results.datesGoingDown = datesStr(results.goingDown);
results.daysGoingDown = dates(results.goingDown);

results.datesGoingDownWithBuffer = create_buffer(results.daysGoingDown, dayBuffer);

results = calc_most_recent_buysell_event(results);





function results = calc_most_recent_buysell_event(results)
%adds fields to the results structure indicating what, if any, was the last
%buy/sell event

if isempty(results.datesGoingDown) && ~isempty(results.datesGoingUp)
    results.mostRecentDir = 'up';
    results.mostRecentDateEqual = results.datesGoingUp(end);
    results.daysAgo = calc_day_difference(results.mostRecentDateEqual, now);
    return
end
    

if ~isempty(results.datesGoingDown) && isempty(results.datesGoingUp)
    results.mostRecentDir = 'down';
    results.mostRecentDateEqual = results.datesGoingDown(end);
    results.daysAgo = calc_day_difference(results.mostRecentDateEqual, now);
    return
end

if isempty(results.datesGoingDown) && isempty(results.datesGoingUp)
%     no match
    results.mostRecentDir = '';
    results.mostRecentDateEqual = {};
    results.daysAgo = [];
    return
end

if datenum(results.datesGoingDown(end)) > datenum(results.datesGoingUp(end))
    results.mostRecentDir = 'down';
    results.mostRecentDateEqual = results.datesGoingDown(end);
    results.daysAgo = calc_day_difference(results.mostRecentDateEqual, now);
else
    results.mostRecentDir = 'up';
    results.mostRecentDateEqual = results.datesGoingUp(end);
    results.daysAgo = calc_day_difference(results.mostRecentDateEqual, now);
end







function [results] = get_rsi_results(prices,dates, rsiPeriod, datesStr, dayBuffer)
results.high.mostRecentInd=[]; 
results.high.mostRecentDateEqual=[];  
results.high.daysAgo=[];
results.high.datesOfInterest= [];
results.high.upOrDown=[];
results.high.upOrDownSign=[];

results.low.mostRecentInd=[]; 
results.low.mostRecentDateEqual=[];  
results.low.daysAgo=[];
results.low.datesOfInterest= [];
results.low.upOrDown=[];
results.low.upOrDownSign=[];


results.rsi = rsi(prices,rsiPeriod);
histogramDataLow = results.rsi-30;
results.rsiLowGoingUp = find(diff(sign(histogramDataLow))>0); % crossing 30, going up
results.low.datesStr = datesStr(results.rsiLowGoingUp);
results.low.dates = dates(results.rsiLowGoingUp);

if ~isempty(results.rsiLowGoingUp)
    results.low.mostRecentInd = results.rsiLowGoingUp(end);
    results.low.mostRecentDateEqual = datestr(dates(results.low.mostRecentInd),23);
    results.low.daysAgo = calc_day_difference(results.low.mostRecentDateEqual, now);
end

results.datesGoingUpWithBuffer = create_buffer(results.low.dates, dayBuffer);



histogramDataHigh = results.rsi-70;
results.rsiHighGoingDown  = find(diff(sign(histogramDataHigh))<0); % crossing 70, going down
results.high.datesStr = datesStr(results.rsiHighGoingDown);
results.high.dates = dates(results.rsiHighGoingDown);

if ~isempty(results.rsiHighGoingDown)
    results.high.mostRecentInd = results.rsiHighGoingDown(end);
    results.high.mostRecentDateEqual = datestr(dates(results.high.mostRecentInd),23);
    results.high.daysAgo = calc_day_difference(results.high.mostRecentDateEqual, now);
end

results.datesGoingDownWithBuffer = create_buffer(results.high.dates, dayBuffer);


function datestrCellArray = create_buffer(daysVector, dayBuffer)
%returns cell array of input days (inDaysVec) with +/- dayBuffer days
%surrounding each input day
%
% Example: daysVector =
%       735588
%       735601
% dayBuffer = 1;
% resultsWithBuffer = 
%     '12/19/2013'
%     '12/20/2013'
%     '12/21/2013'
%     '01/01/2014'
%     '01/02/2014'
%     '01/03/2014'
if nargin == 1
    dayBuffer = 3;
end
if isempty(daysVector)
    datestrCellArray = {};
else
    datestrCellArray={};
    for i=1:length(daysVector)
        % add days in past
        for j = dayBuffer:-1:1
            datestrCellArray{end+1,1} = datestr(addtodate(daysVector(i),-j,'day'),23);
        end
        
        %input day
        datestrCellArray{end+1,1} = datestr(daysVector(i),23);
        
        %add days in future
        for j = 1:dayBuffer
            datestrCellArray{end+1,1} = datestr(addtodate(daysVector (i),j,'day'),23);
        end
    end
    
    %only use unique days since there will probably be some commonDates
    datestrCellArray = unique(datestrCellArray);
    %sort dates
    datestrCellArray = sort_datesStr(datestrCellArray);
end




function sortedResults = sort_datesStr(inStrs)
% inStrs = cell array of strings
if isempty(inStrs)
    sortedResults = '';
else
    sortedResults = sort(datenum(inStrs));
    sortedResults=cellstr(datestr(sortedResults,23));
end




function daysAgo = calc_day_difference(t1, t2)
curYear = datestr(t2,10);
macdYear = datestr(t1, 10);
yearDiff = str2num(curYear) - str2num(macdYear);

curMonth = datestr(t2,5);
macdMonth= datestr(t1, 5);
monthDiff = str2num(curMonth) - str2num(macdMonth);

curDay = datestr(t2,7);
macdDay = datestr(t1, 7);
dayDiff = str2num(curDay) - str2num(macdDay);

daysAgo = yearDiff*365 + monthDiff*30 + dayDiff;





function start_date = get_start_date(stockDataWindow)
% set default dates to stockDataWindow mo in past to today
curMonth = str2num(datestr(now,5));
sMonth = curMonth - stockDataWindow; % stockDataWindow month history
sYear = datestr(now,10);
% if in a previous year
while sMonth <= 0
    sMonth = sMonth + 12;
    sYear = num2str(str2num(sYear) - 1);
end
sMonth = num2str(sMonth);
start_date = datestr([sMonth '/01/' sYear],23);




function [success, msg, prices, dates, datesStr, volumes, stockName] = get_stock_data(ticker, stockDataWindow)
success = false;
msg = [];
prices=[];
dates=[];
datesStr={};
volumes=[];
stockName = [];

% compute start and end dates
startDate = get_start_date(stockDataWindow); %in the past on the first of a month
endDate = datestr(now,23); % always today

if startDate >= now
    % if only this data were available :)
    success = false;
    msg = 'Start date cannot be in the future';
    return
end

getStockNameCmd=['http://quote.yahoo.com/d/quotes.csv?s=' ticker '&f=n'];
stockNameWithExtraChars = urlread(getStockNameCmd);
stockNameWithWhitespaces = stockNameWithExtraChars(2:end-3); % strip out quotes and newlines
stockName = regexprep(stockNameWithWhitespaces,'(\s+\S+$)',''); % strip out last fragment of characters

startDate = datestr(startDate,23);
monthStart = num2str(round(str2double(startDate(1:2))-1));
endDate = datestr(endDate,23);
monthEnd = num2str(round(str2double(endDate(1:2))-1));

% Form URL to read.  Note that months go from 0 to 11.
%
% example for ticker 'spy' (s&p 500) from 8/01/11 to 6/21/2012:
% http://ichart.yahoo.com/table.csv?s=ba&a=7&b=01&c=2011&d=5&e=21&f=2012&g=d&ignore=.csv
urlstr = ['http://ichart.yahoo.com/table.csv?s=',...
    ticker,'&a=',monthStart,'&b=',startDate(4:5),'&c=',startDate(7:end),...
    '&d=',monthEnd,'&e=',endDate(4:5),'&f=',endDate(7:end),'&g=d&ignore=.csv'];
try
    % ping yahoo's servers for stock data
    data = urlread(urlstr);
    [prices, dates, datesStr, volumes] = parse_yahoo_data(data);
    success = true;
catch ME
    % Something went wrong, display error message and abort
    msg = ME.message;
    success = false;
end





function [prices,dates,datesStr,volumes] = parse_yahoo_data(dataIn)
prices=[];
dates=[];
datesStr={};
volumes=[];
dataLines = regexp(dataIn,'([^\n]*)','match');% separate data at carriage returns
str = dataLines{1};
pat = '[^,]+';
headings=regexp(str,pat,'match');
for i =1:length(headings)
    if strcmpi(headings{i},'close')
        priceInd = i;
    elseif strcmpi(headings{i},'date')
        dateInd = i;
    elseif strcmpi(headings{i},'volume')
        volInd=i;
    end
end

for i=2:length(dataLines)
    str=dataLines{i};
    pat = '[^,]+';
    matchInfo = regexp(str,pat,'match');
    prices(i-1,1) = str2num(matchInfo{priceInd});
    dates(i-1,1) = datenum(matchInfo{dateInd},'yyyy-mm-dd');
    datesStr{i-1,1} = datestr(dates(i-1,1),23);
    volumes(i-1,1) =str2num(matchInfo{volInd});
end

% Reverse order
% 1st element should be oldest
prices = prices(end:-1:1);
volumes = volumes(end:-1:1);
dates = dates(end:-1:1);
datesStr = datesStr(end:-1:1);



function smaOutput = sma(prices,smaPeriod)
% Simple moving average of prices over 'smaPeriod' points
% prices(1) == oldest data, prices(end) == newest data

smaOutput = filter(ones(1,smaPeriod)/smaPeriod, 1, prices);            
smaOutput(1:smaPeriod-1) = nan; % the first smaPeriod-1 points are meaningless



function varargout = macd(data,p1,p2,p3)
% [mavg1,mavg2] = macd(data,p1,p2,p3)
% Function to calculate the moving average convergence/divergence of a data set
% 'data' is the vector to operate on.  The first element is assumed to be
% the oldest data.
%
% p1 and p2 are the number of periods over which to calculate the moving
% averages that are subtracted from each other.
% p3 is the period of the indicator moving average
%
% If called with one output then it will be a two column matrix containing
% both calculated series.
% If called with two outputs then the first will contain the macd series
% and the second will contain the indicator series.
%
% Example:
% mavg1 = macd(data,p1,p2,p3);
% [mavg1,mavg2] = macd(data,p1,p2,p3);


switch nargin
    case 1
        p1 = 26;
        p2 = 12;
        p3 = 9;
    case 2
        p2 = 12;
        p3 = 9;
    case 3
        p3 = 9;
end

% calculate the MACD
mavg1 = ema(data,p2)-ema(data,p1);
% Need to be careful with handling NaN's in the second calculation
idx = isnan(mavg1);
mavg2 = [mavg1(idx); ema(mavg1(~idx),p3)];
switch nargout
    case {0,1}
        varargout{1} = [mavg1 mavg2];
    case 2
        varargout{1} = mavg1;
        varargout{2} = mavg2;
    otherwise
        error('Too many outputs have been requested.');
end


function out = rsi(data,period)
% Function to calculate the Relative Strength Index of a data set
% 'data' is the vector to operate on.  The first element is assumed to be
% the oldest data.
% 'period' is the length of the Wilder Smoothing window.
%
% Example:
% out = rsi(data,period)
%

% Error check
if nargin ~=2
    error([mfilename,' requires 2 inputs.']);
end
[m,n]=size(data);
if ~(m==1 || n==1)
    error(['The first input to ',mfilename,' must be a vector.']);
end
if numel(period) ~= 1
    error('The Wilder smoothing period must be a scalar.');
end
if length(data) < period+1
    error('The data set must be at least 1 element longer than the requested RSI period.');
end

% calculate the up and down data changes
dd = diff(data);
uc = dd;
uc(uc<0)=0;
dc = dd;
dc(dc>0)=0;
dc = -dc;
% perform Wilder Smoothing
wuc = wildersmoothing(uc,period);
wdc = wildersmoothing(dc,period);
% calculate the RSI (taking account of nan's in wuc and wdc)
out = [nan*ones(period-1,1); 100-(100./(1+wuc(period-1:end)./wdc(period-1:end)))];



function out = wildersmoothing(data,period)
% Function to perform Wilder Smoothing on a data set
% 'data' is the vector of values to be smoothed.  The first element is assumed to be
% the oldest data.
% 'period' is the length of the smoothing window.
%
% Example:
% out = wildersmoothing(data,period)
%

% Error check
[m,n]=size(data);
if ~(m==1 || n==1)
    error(['The first input to ',mfilename,' must be a vector.']);
end
if numel(period) ~= 1
    error('The Wilder smoothing period must be a scalar.');
end

% perform the filtering
ld = length(data);
if ld < period
    error('The data vector must be at least as long as the required period of smoothing.');
elseif ld == period
    out = mean(data);
else
    out = nan*ones(size(data));
    out(period:end) = filter(1/period,[1 -(period-1)/period],data(period:end),sum(data(1:(period-1)))/period);
end


function out = ema(data,period)
% Function to calculate the exponential moving average of a data set
% 'data' is the vector to operate on.  The first element is assumed to be
% the oldest data.
% 'period' is the number of periods over which to calculate the average
%
% Example:
% out = ema(data,period)
%

% Error check
if nargin ~= 2
    error([mfilename,' requires 2 inputs.']);
end
[m,n]=size(data);
if ~(m==1 || n==1)
    error(['The data input to ',mfilename,' must be a vector.']);
end
if (numel(period) ~= 1)
    error('The period must be a scalar.');
end

% convert the period to an exponential percentage
ep = 2/(period+1);
% calculate the EMA
out = filter(ep,[1 -(1-ep)],data,data(1)*(1-ep));
out(1:period-1)=nan;







function [bool]=cregexp(str,rstr,case_insensitive)
%[bool]=main(str,rstr,case_insensitive)
%returns true if str contains rstr
if ~exist('case_insensitive','var')
    case_insensitive=false;
end
if ~iscell(str)
    str={str};
end

if case_insensitive
    bool=cellfun(@isempty,regexpi(str,rstr))==0;
else
    bool=cellfun(@isempty,regexp(str,rstr))==0;
end





function handles = plot_smr_data(handles)
% raw data 
ticker = handles.UserData.ticker ;
stockName = handles.UserData.stockName;
dates = handles.UserData.dates ;
volumes = handles.UserData.volumes;
prices = handles.UserData.prices ;
macdRes = handles.UserData.macdRes ;
smaRes = handles.UserData.smaRes ;
rsiRes = handles.UserData.rsiRes ;
buyDates = handles.UserData.buyDates ;
sellDates = handles.UserData.sellDates ;
pricesOnBuyDates = handles.UserData.pricesOnBuyDates ;
pricesOnSellDates = handles.UserData.pricesOnSellDates ;

% user's choice on what to plot
showPrice = get(handles.checkbox_showPrice,'value');
showMacd = get(handles.checkbox_showMacd,'value');
showRsi = get(handles.checkbox_showRsi,'value');
showVolume = get(handles.checkbox_showVolume,'value');
showSma = get(handles.checkbox_showSma,'value');
coplotVolume = get(handles.checkbox_coplotVolume,'value');

% show one row for each checkbox
numRows=showPrice+showMacd+showRsi+showSma+showVolume; % adding boolean values
curRow = 1;

% set up plot properties
markerSize=5;
blueRgb = [0,0.4000,1.0000];
sp = []; %subplot handles will be appended to this array

%% Stock price with buy/sell symbols
if showPrice
    sp(end+1,1) = subplot(numRows,1,curRow,'parent',handles.uipanel_plots);
    cla
    if isempty(ticker)
         title('stock price')
    else
         title([stockName ' (' ticker ') stock price'])
    end
   
    hold on
    grid on
    plot(dates,prices,'color',blueRgb,'LineWidth',1)
    axis auto
    yl=ylim;
    jbfill(dates',prices',zeros(1,length(prices)),[0,0.4000,1.0000],[0,0.4000,1.0000],1,.1); 
    hold on
    plot(buyDates,  pricesOnBuyDates,'go','MarkerSize',markerSize, 'MarkerFaceColor','g','MarkerEdgeColor','k', 'Marker','o')
    plot(sellDates, pricesOnSellDates,'ro','MarkerSize',markerSize, 'MarkerFaceColor','r','MarkerEdgeColor','k', 'Marker','o')
    ylabel('stock price, USD')
    ylim(yl)
    xl = xlim;
    
    if numel(dates) > 0 
        xlim([dates(1), xl(2)]);
        yl=ylim;
        if coplotVolume
            yTickArray=get(gca,'YTick');
            expandBy = yTickArray(2)-yTickArray(1);
            ylim([yl(1)-expandBy, yl(2)])
            yl=ylim;
            scl = abs((min(prices) - yl(1)) / max(volumes)); %scale data to fit under price timeseries data
            bar(dates,volumes.*scl+yl(1),'edgecolor','g','facecolor','g')
        end
        xlabs=get_xtick(dates);
        set(gca,'XTick',xlabs);
        set(gca,'Xticklabel',datestr(xlabs,'mm/yy'))
    end
    curRow = curRow +1;
end

%% MACD
if showMacd
    sp(end+1,1) = subplot(numRows,1,curRow,'parent',handles.uipanel_plots);
    cla
    hold on
    grid on
    title('moving avg convergence/divergence (macd)')
    if numel(dates) > 0
        plot(dates,macdRes.macdIndicator,'color','m')
        plot(dates,macdRes.macdDiff,'color',blueRgb)
        legend('Indicator','MACD','Location','SouthWest')
        plot(dates(macdRes.goingUp),macdRes.macdIndicator(macdRes.goingUp),'go','MarkerSize',markerSize, 'MarkerFaceColor','g','MarkerEdgeColor','k', 'Marker','o')
        plot(dates(macdRes.goingDown),macdRes.macdIndicator(macdRes.goingDown),'ro','MarkerSize',markerSize, 'MarkerFaceColor','r','MarkerEdgeColor','k', 'Marker','o')
        axis auto
        xl = xlim;
        xlim([dates(1), xl(2)]);
        xlabs=get_xtick(dates);
        set(gca,'XTick',xlabs);
        set(gca,'Xticklabel',datestr(xlabs,'mm/yy'))   
    end
    curRow = curRow +1;
end

%% SMA
if showSma
    sp(end+1,1) = subplot(numRows,1,curRow,'parent',handles.uipanel_plots);
    cla
    hold on
    grid on
    title('simple moving average (sma)')
    if numel(dates) > 0
        plot(dates,smaRes.price,'m')
        plot(dates,prices,'color',blueRgb)
         legend('SMA','Price','Location','SouthWest')
        plot(dates(smaRes.goingUp),smaRes.price(smaRes.goingUp),'go','MarkerSize',markerSize, 'MarkerFaceColor','g','MarkerEdgeColor','k', 'Marker','o')
        plot(dates(smaRes.goingDown),smaRes.price(smaRes.goingDown),'ro','MarkerSize',markerSize, 'MarkerFaceColor','r','MarkerEdgeColor','k', 'Marker','o')
        axis auto
        xl = xlim;
        xlim([dates(1), xl(2)]);
        xlabs=get_xtick(dates);
        set(gca,'XTick',xlabs);
        set(gca,'Xticklabel',datestr(xlabs,'mm/yy'))
    end
    curRow = curRow +1;
end

%% RSI
if showRsi
    sp(end+1,1) = subplot(numRows,1,curRow,'parent',handles.uipanel_plots);
    cla
    hold on
    grid on
    title('relative strength index (rsi)')
    if numel(dates) > 0
        %plot shaded red and green regions
        jbfill([dates(1),dates(end)],[30,30],[1,1], [0.6000    1.0000    0.6000],[0.6000    1.0000    0.6000], 0.5, 0.5) ;
        hold on
        jbfill([dates(1),dates(end)],[70,70],[100,100], [1.0000    0.4000    0.4000],[1.0000    0.4000    0.4000],0.5,0.5) ;
        hold on
        
        plot(dates,rsiRes.rsi,'color',blueRgb)
        plot([dates(1), dates(end)], [30,30],'k--','linewidth',1)
        plot([dates(1), dates(end)], [70,70],'k--','linewidth',1)
        plot(dates(rsiRes.rsiLowGoingUp), rsiRes.rsi(rsiRes.rsiLowGoingUp),'go', 'MarkerSize',markerSize, 'MarkerFaceColor','g','MarkerEdgeColor','k', 'Marker','o')
        plot(dates(rsiRes.rsiHighGoingDown), rsiRes.rsi(rsiRes.rsiHighGoingDown),'ro','MarkerSize',markerSize, 'MarkerFaceColor','r','MarkerEdgeColor','k', 'Marker','o')
        axis auto
        xl = xlim;
        xlim([dates(1), xl(2)]);
        xlabs=get_xtick(dates);
        set(gca,'XTick',xlabs);
        set(gca,'Xticklabel',datestr(xlabs,'mm/yy'))
    end
    curRow = curRow +1;
end

%% Volume
if showVolume
    sp(end+1,1) = subplot(numRows,1,curRow,'parent',handles.uipanel_plots);
    cla
    hold on
    grid on
    title('volume')
    if numel(dates) > 0
        bar(dates,volumes,'edgecolor','g','facecolor','g')
        xl = xlim;
        xlim([dates(1), xl(2)]);
        xlabs=get_xtick(dates);
        set(gca,'XTick',xlabs);
        set(gca,'Xticklabel',datestr(xlabs,'mm/yy'))
    end
    curRow = curRow +1;
end

linkaxes(sp, 'x')

% Update handles structure
guidata(handles.uipanel_plots, handles);


function xticks = get_xtick(dates)
months = str2num(datestr(dates,5));
years = str2num(datestr(dates,10));
xticks=[];
xticks(end+1) = dates(1);
while str2num(datestr(xticks(end),5)) < months(end) ||   str2num(datestr(xticks(end),10)) < years(end)
    xticks(end+1) = addtodate(xticks(end),1,'month');
end


% --- Executes on button press in checkbox_showPrice.
function checkbox_showPrice_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_showPrice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_showPrice
handles = update_plots(hObject, eventdata, handles);

% --- Executes on button press in checkbox_coplotVolume.
function checkbox_coplotVolume_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_coplotVolume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_coplotVolume
handles = update_plots(hObject, eventdata, handles);

% --- Executes on button press in checkbox_showMacd.
function checkbox_showMacd_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_showMacd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_showMacd
handles = update_plots(hObject, eventdata, handles);

% --- Executes on button press in checkbox_showSma.
function checkbox_showSma_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_showSma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_showSma
handles = update_plots(hObject, eventdata, handles);

% --- Executes on button press in checkbox_showRsi.
function checkbox_showRsi_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_showRsi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_showRsi
handles = update_plots(hObject, eventdata, handles);

% --------------------------------------------------------------------
function uipanel2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uipanel2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% init plots

% --- Executes during object creation, after setting all properties.
function uipanel2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


function handles = update_plots(hObject, eventdata, handles)
if isfield(handles,'UserData')
    handles = plot_smr_data(handles);
else
    % init plots
    showPrice = get(handles.checkbox_showPrice,'value');
    showMacd = get(handles.checkbox_showMacd,'value');
    showRsi = get(handles.checkbox_showRsi,'value');
    showVolume = get(handles.checkbox_showVolume,'value');
    showSma = get(handles.checkbox_showSma,'value');
    
    numRows=showPrice+showMacd+showRsi+showVolume+showSma+showVolume;
    
    for i = 1:numRows
        subplot(numRows,1,i,'parent',handles.uipanel_plots);
        cla
    end
end


% --------------------------------------------------------------------
function run_multiple_Callback(hObject, eventdata, handles)
% hObject    handle to run_multiple (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in radiobutton_batchTickers.
function radiobutton_batchTickers_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_batchTickers (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_batchTickers



% --- Executes when selected object is changed in uipanel3.
function uipanel3_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel3 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function uipanel3_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uipanel3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over radiobutton_batchTickers.
function radiobutton_batchTickers_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to radiobutton_batchTickers (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function uipanel6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when selected object is changed in uipanel6.
function uipanel6_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel6 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
if get(handles.radiobutton_batchTickers,'value')
    set(handles.pushbutton_submitQuery,'string','smr_strategy to pdf')
    if exist('C:\Temp','dir')
        fid = fopen('C:\Temp\metricsUserTickers.txt','r');
        userTickers  = fgetl(fid);
    end
    set(handles.edit_ticker,'string',userTickers)
else
    set(handles.pushbutton_submitQuery,'string','Get smr_strategy')
end


% --- Executes on selection change in popupmenu_tickersHistory.
function popupmenu_tickersHistory_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_tickersHistory (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_tickersHistory contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_tickersHistory
value = get(hObject,'value');
tickerList =  get(hObject,'string');
set(handles.edit_ticker,'string',tickerList{value});

% --- Executes during object creation, after setting all properties.
function popupmenu_tickersHistory_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_tickersHistory (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function checkbox_showVolume_Callback(hObject, eventdata, handles)
handles = update_plots(hObject, eventdata, handles);

function[fillhandle,msg]=jbfill(xpoints,upper,lower,color,edge,add,transparency)
%USAGE: [fillhandle,msg]=jbfill(xpoints,upper,lower,color,edge,add,transparency)
%This function will fill a region with a color between the two vectors provided
%using the Matlab fill command.
%
%fillhandle is the returned handle to the filled region in the plot.
%xpoints= The horizontal data points (ie frequencies). Note length(Upper)
%         must equal Length(lower)and must equal length(xpoints)!
%upper = the upper curve values (data can be less than lower)
%lower = the lower curve values (data can be more than upper)
%color = the color of the filled area 
%edge  = the color around the edge of the filled area
%add   = a flag to add to the current plot or make a new one.
%transparency is a value ranging from 1 for opaque to 0 for invisible for
%the filled color only.
%
%John A. Bockstege November 2006;
%Example:
%     a=rand(1,20);%Vector of random data
%     b=a+2*rand(1,20);%2nd vector of data points;
%     x=1:20;%horizontal vector
%     [ph,msg]=jbfill(x,a,b,rand(1,3),rand(1,3),0,rand(1,1))
%     grid on
%     legend('Datr')
if nargin<7;transparency=.5;end %default is to have a transparency of .5
if nargin<6;add=1;end     %default is to add to current plot
if nargin<5;edge='k';end  %dfault edge color is black
if nargin<4;color='b';end %default color is blue

if length(upper)==length(lower) && length(lower)==length(xpoints)
    msg='';
    filled=[upper,fliplr(lower)];
    xpoints=[xpoints,fliplr(xpoints)];
    if add
        hold on
    end
    fillhandle=fill(xpoints,filled,color);%plot the data
    set(fillhandle,'EdgeColor',edge,'FaceAlpha',transparency,'EdgeAlpha',transparency);%set edge color
    if add
        hold off
    end
else
    msg='Error: Must use the same number of points in each vector';
end





% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over edit_ticker.
function edit_ticker_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to edit_ticker (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%NOTE:
% Some code from Phil Goddard and John Bockstege are included in this file.
% Redistribution and use in source and binary forms, with or without 
% modification, are permitted provided that the following conditions are 
% met:
% 
%     * Redistributions of source code must retain the above copyright 
%       notice, this list of conditions and the following disclaimer.
%     * Redistributions in binary form must reproduce the above copyright 
%       notice, this list of conditions and the following disclaimer in 
%       the documentation and/or other materials provided with the distribution
%       
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
% POSSIBILITY OF SUCH DAMAGE.


% --- Executes on key press with focus on edit_stockDataWindow and none of its controls.
function edit_stockDataWindow_KeyPressFcn(hObject, eventdata, handles)


% --- Executes on key press with focus on edit_ticker and none of its controls.
function edit_ticker_KeyPressFcn(hObject, eventdata, handles)




% --- Executes on key press with focus on edit_smaPeriod and none of its controls.
function edit_smaPeriod_KeyPressFcn(hObject, eventdata, handles)



% --- Executes on key press with focus on edit_dayBuffer and none of its controls.
function edit_dayBuffer_KeyPressFcn(hObject, eventdata, handles)



% --- Executes on key press with focus on edit_macdP1 and none of its controls.
function edit_macdP1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to edit_macdP1 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on edit_macdP2 and none of its controls.
function edit_macdP2_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to edit_macdP2 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on edit_macdP3 and none of its controls.
function edit_macdP3_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to edit_macdP3 (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on edit_rsiPeriod and none of its controls.
function edit_rsiPeriod_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to edit_rsiPeriod (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
msgbox(sprintf(['Stock ticker.\n\n' ...
    'Recommended tickers:\n' ...
    'spy - S&P 500\n' ...
    'dia - Dow Jones Industrial Avg']));
